# CHANGELOG

## Version 4
- Cleanup

## Version 3
- Translatable
- Dutch translations
- Compatible with 3.38 and 3.36

## Version 2
- fix right tile wrong gab size
- review instructions

## Version 1

- initial version
- preference for gap size
- override maximize function
- override tile left/right function
- initial information and docs

